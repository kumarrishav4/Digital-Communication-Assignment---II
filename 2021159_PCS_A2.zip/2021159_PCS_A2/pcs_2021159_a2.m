%% PCS Assignment 2 
% Kumar Rishav(2021159)
clc; clear; close all;

%% Problem 1: Audio and Sampling 
fprintf('Problem 1: Audio Signal Analysis\n');

% Importing recorded audio in matlab
[x, Fs] = audioread('kumarrishav_pcs.wav');
x = x(:,1); 
t = (0:length(x)-1)/Fs;


% Plotting and playing original time-domain signal
figure;
plot(t, x); title('Original Time-Domain Signal');
xlabel('Time [s]'); ylabel('Amplitude');
sound(x,Fs);

%% Plotting Frequency spectrum for the orignal signal
X =fftshift(fft(x));
f =linspace(-Fs/2, Fs/2, length(X));
figure; 
plot(f,abs(X)); title('Original Magnitude Spectrum');
xlabel('Frequency [Hz]'); ylabel('Magnitude');

%% passing orignal signal through a low-pass filter (4 kHz)
x_filtered = lowpass(x, 4000, Fs);

% Filtered spectrum
Xf =fftshift(fft(x_filtered));
figure; 
plot(f, abs(Xf)); title('Filtered Magnitude Spectrum');
xlabel('Frequency [Hz]');

%% Downsampling the filtered signal
Fs_below = 6000; Fs_above = 16000;
x_below = resample(x_filtered, Fs_below, Fs);
x_above = resample(x_filtered, Fs_above, Fs);

% Plotting sampled spectrums
figure;
subplot(2,1,1);
plot(linspace(-Fs_below/2, Fs_below/2, length(x_below)),abs(fftshift(fft(x_below))));
title('Spectrum - Below Nyquist'); xlabel('Frequency [Hz]');

subplot(2,1,2);
plot(linspace(-Fs_above/2, Fs_above/2, length(x_above)),abs(fftshift(fft(x_above))));
title('Spectrum - Above Nyquist'); xlabel('Frequency [Hz]');

% Reconstruction of signal from nyquist sampling
y_r = resample(x_below, Fs, Fs_below);
figure;
plot((0:length(y_r)-1)/Fs, y_r);
title('Reconstructed Signal from Below Nyquist Sampling Rate');

%% Problem 2: Quantization
fprintf('Problem 2: Quantization\n');

L_values = [8, 16, 32, 64, 128];
MSE = zeros(size(L_values));
bits_used = zeros(size(L_values));

for i = 1:length(L_values)
    L = L_values(i);
    [q_sig, bits_used(i)] = quantize_signal(x_filtered, L);
    
    % Reconstruct signal from quantized version
    reconstructed_signal = digtoanalog(q_sig);
    
    % Compute Mean Square Error
    MSE(i) = mean((x_filtered - reconstructed_signal).^2);
end

% Plotting MSE vs Quantization Levels
figure;
stem(L_values, MSE, '-o'); grid on;
xlabel('Quantization Levels (L)');
ylabel('Mean Square Error (MSE)');
title('Quantization Error vs Levels');

fprintf('Bits used at L=128: %d\n', bits_used(end));
sound(reconstructed_signal, Fs);

%% Problem 3: Line Coding
fprintf('Problem 3: Line Coding and Eye Diagram \n');

bits = randi([0 1], 1, 100);  
polar_nrz = 2*bits - 1;      
Tb = 1e-3; Fs_line = 1e5;     
samples_per_bit = round(Fs_line * Tb);
line_code = repelem(polar_nrz, samples_per_bit);

t_line = (0:length(line_code)-1)/Fs_line;
figure;
plot(t_line(1:20*samples_per_bit), line_code(1:20*samples_per_bit));
title('Polar NRZ Line Code - First 20 bits'); xlabel('Time [s]');
% plotting the eyediagram for Polar NRZ
eyediagram(line_code, 2*samples_per_bit);
title('Eye Diagram: Polar NRZ');

%% Problem 4: Raised Cosine Pulse 
fprintf('Problem 4: Raised Cosine Pulse Shapes \n');

T = 1; t_rc = -5:0.01:5;
sinc_pulse = sinc(t_rc);
rc_05 = raised_cosine(t_rc, T, 0.5);
rc_075 = raised_cosine(t_rc, T, 0.75);
% plotting rc(Raised cosine Signal
figure;
plot(t_rc, sinc_pulse, 'k', 'LineWidth',1.5); hold on;
plot(t_rc, rc_05, 'r--', 'LineWidth',1.5);
plot(t_rc, rc_075, 'b-.', 'LineWidth',1.5);
legend('Sinc (r=0)', 'Raised Cosine r=0.5', 'Raised Cosine r=0.75');
xlabel('Time'); ylabel('Amplitude'); title('Raised Cosine Pulses');

%% Problem 5: Transmit and Noise 
fprintf('Problem 5: Transmit Raised Cosine + AWGN \n');

rc_pulse = rc_05; 
tx_signal = conv(line_code, rc_pulse, 'same');
% Plotting Eye diagram for Transmit Signal with Raised Cosine
eyediagram(tx_signal, 2*samples_per_bit);
title('Eye Diagram of Transmit Signal with Raised Cosine');

% Adding  AWGN noise
r1 = awgn(tx_signal, 10*log10(1/0.5), 'measured');
r2 = awgn(tx_signal, 10*log10(1/2), 'measured');

figure;
subplot(2,1,1); plot(r1); title('Received Signal σ² = 0.5');
subplot(2,1,2); plot(r2); title('Received Signal σ² = 2');

eyediagram(r1, 2*samples_per_bit);
title('Eye Diagram σ² = 0.5');
eyediagram(r2, 2*samples_per_bit);
title('Eye Diagram σ² = 2');
sound (r1,Fs);


%% Quantization Function
function [q_out, total_bits] = quantize_signal(signal, L)
    min_val = min(signal);
    max_val = max(signal);
    q_step = (max_val - min_val) / L;
    
    centers = min_val + q_step*(0.5:1:L-0.5); % Mid-rise quantizer
    q_out = zeros(size(signal));
    
    for i = 1:length(signal)
        [~, idx] = min(abs(signal(i) - centers));
        q_out(i) = centers(idx);
    end
    
    % Calculate total bits used
    total_bits = length(signal) * ceil(log2(L));
end

%% Digital to Analog Reconstruction Function
function analog_signal = digtoanalog(quantized_signal)
    % Ideal reconstruction (no interpolation or filtering needed)
    analog_signal = quantized_signal;
end

%% Raised cosine Function
function p = raised_cosine(t, T, beta)
    p = zeros(size(t));
    for i = 1:length(t)
        if abs(1 - (2*beta*t(i)/T)^2) < 1e-5
            p(i) = (pi/4)*sinc(1/(2*beta));
        elseif abs(t(i)) < 1e-8
            p(i) = 1;
        else
            numerator = sinc(t(i)/T) * cos(pi*beta*t(i)/T);
            denominator = 1 - (2*beta*t(i)/T)^2;
            p(i) = numerator / denominator;
        end
    end
end
